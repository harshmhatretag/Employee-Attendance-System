package com.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.project.Employee;

@Component(value = "employeeDao")
public class EmployeeDao {

	@Autowired
	EntityManagerFactory entityManagerFactory;
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	EntityTransaction entityTransaction;
	
	public Employee saveEmployee(Employee employee)
	{
		entityTransaction.begin();
		entityManager.persist(employee);
		entityTransaction.commit();
		return employee;
	}
	
	public Employee updateEmployee(Employee employee)
	{
		entityTransaction.begin();
		entityManager.merge(employee);
		entityTransaction.commit();
		return employee;
	}
	
	public Employee getEmpByPhnoPwd(long phno, String pwd)
	{
		Query q= entityManager.createQuery("select e from Employee e where e.phoneNumber=?1 and e.password=?2");
		q.setParameter(1, phno);
		q.setParameter(2, pwd);
		
		List<Employee> list= q.getResultList();
		if(list.size()>=1)        //check kela databace mdhla data jo list mdhe ghetla aahe tyachi size hi 1 peksha mothi aahe kay ? mhanjech databace empty nahi n he check kel...
		{
			return list.get(0);    //jr empty nasel tr list mdhla 1st element ghetla. mhanjech 0th index cha data ghetla...Ani return kela..
		}
		else                      //jr empty asel tr....?
		{
			return null;          //empty asel tr null return kel...
		}
	}
}
