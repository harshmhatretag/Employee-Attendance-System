package com.spring.dri;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.conf.MyConfig;
import com.spring.dao.AttendanceDao;
import com.spring.dao.EmployeeDao;
import com.spring.project.Attendance;
import com.spring.project.Employee;

public class Driver {
	
	public static void main(String[] args) {
		
		ApplicationContext context= new AnnotationConfigApplicationContext(MyConfig.class);
		
		Scanner scanner= (Scanner)context.getBean("scan");
		
		Employee employee= (Employee)context.getBean("employee");
		EmployeeDao employeeDao= (EmployeeDao)context.getBean("employeeDao");
		
		Attendance attendance= (Attendance)context.getBean("attendance");
		AttendanceDao attendanceDaa= (AttendanceDao)context.getBean("attendanceDao");
		
		while(true)
		{
			System.out.println("1: Register \n2: Login \n3: Exit");
			System.out.println("Enter Choise..");
			int choise= scanner.nextInt();
			
			switch(choise)
			{
			
			case 1:
			{
				//Register
				System.out.println("Enter Name: ");
				employee.setEmpName(scanner.next());
				System.out.println("Enter Email: ");
				employee.setEmail(scanner.next());
				System.out.println("Enter PhoneNumber: ");
				employee.setPhoneNumber(scanner.nextLong());
				System.out.println("Enter Password");
				employee.setPassword(scanner.next());
				
				//save
				employeeDao.saveEmployee(employee);
				System.out.println("Employee Saved...");
			}
			break;
			
			
			
			case 2:
			{
				//Login
				System.out.println("Enter PhoneNumber: ");
				long phno= scanner.nextLong();
				System.out.println("Enter Password: ");
				String pwd= scanner.next();
				
				Employee emp= employeeDao.getEmpByPhnoPwd(phno, pwd);    //ji value/data getEmpByPhonePwd() method ni return kela to (emp) object mdhe store zala....
				if(emp==null)    //emp object mdhe store zaleli value null aahe kay check keli
				{
					System.out.println("Register First...");
				}
				else
				{
					attendanceDaa.saveAttendance(attendance);
					
					List<Attendance> list= new ArrayList<Attendance>();
					list.add(attendance);
					
					emp.setAttendance(list);
					employeeDao.updateEmployee(emp);
//					System.out.println(emp);
//					System.out.println(emp.getEmpName());
				}
			}
			break;
			
			
			
			case 3:
			{
				System.out.println("Thank You...");
				System.exit(0);
			}
			break;
			
			}
		}
	}

}
