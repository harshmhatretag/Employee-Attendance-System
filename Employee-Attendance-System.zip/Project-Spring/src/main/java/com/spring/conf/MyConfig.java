package com.spring.conf;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.spring")
public class MyConfig {

	@Bean
	public EntityManagerFactory a()
	{
		return Persistence.createEntityManagerFactory("harsh");
	}
	
	@Bean
	public EntityManager b()
	{
		return a().createEntityManager();
	}
	
	@Bean
	public EntityTransaction c()
	{
		return b().getTransaction();
	}
	
	@Bean(value = "scan")
	public Scanner d()
	{
		return new Scanner(System.in);
	}
}
